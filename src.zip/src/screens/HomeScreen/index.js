import React from "react";
import { Text, View } from "react-native";

const index = () => {
    return (
        <View>
            <Text style= {{fontSize:24, alignSelf: 'center'}}>Home</Text>
        </View>
    )
}
export default index